from __future__ import annotations

import rclpy
from dataclasses import dataclass
from rclpy.action.server import ActionServer, GoalResponse
from typing import Any, Callable, NoReturn, Optional, Union

from vyra_base.com.transport.t_ros2.node import VyraNode


def _base_callback(goal_handle) -> NoReturn:
    """
    Raises
    ======
    NotImplementedError
        If no execute callback is provided for the action server.
    """
    raise NotImplementedError("No execute callback provided for action server.")


@dataclass
class ActionServerInfo:
    """
    Represents an action for the VyraActionServer.

    Attributes
    ----------
    name : str
        Name of the action server.
    type : Any
        Type of the action.
    result_callback : Callable
        Result callback function for the action.
    feedback_callback : Callable
        Feedback callback function for the action.
    server : Union[ActionServer, None]
        The ActionServer instance or None.
    """
    name: str = 'vyra_action_server'
    type: Any = None
    result_callback: Optional[Callable] = _base_callback
    feedback_callback: Optional[Callable] = _base_callback
    server: Union[ActionServer, None] = None


class VyraActionServer:
    """
    Base class for ROS2 actions.

    This class is intended to be factory-created to implement specific action functionality.
    """

    def __init__(self, actionInfo: ActionServerInfo, node: VyraNode) -> None:
        """
        Initialize the VyraActionServer.

        Parameters
        ----------
        action : ActionServerInfo
            The action configuration.
        node : VyraNode
            The ROS2 node to attach the action server to.
        """
        self._action: ActionServerInfo = actionInfo
        self._node: VyraNode = node

    def create_action_server(self) -> None:
        """
        Create and register the action server with the ROS2 node.

        This method should be called to register the action server with the ROS2 node.
        """
        self._node.get_logger().info(f"Creating action: {self._action.name}")
        self._action.server = ActionServer(
            self._node,
            self._action.type,
            self._action.name,
            execute_callback=self.feedback_callback,
            goal_callback=self.goal_callback

        )

    def feedback_callback(self, goal_handle) -> None:
        """
        Execute the action callback.

        This method should be overridden in subclasses to provide specific functionality.

        Parameters
        ----------
        goal_handle : Any
            The goal handle for the action.
        """
        self._node.get_logger().info(f"Executing action: {self._action.name}")

        if self._action.feedback_callback:
            self._action.feedback_callback(goal_handle)

    def goal_callback(self, goal_handle) -> GoalResponse:
        """
        Handle the goal callback.

        This method should be overridden in subclasses to provide specific functionality.

        Parameters
        ----------
        goal_handle : Any
            The goal handle for the action.
        """
        self._node.get_logger().info(f"Handling goal for action: {self._action.name}")


        if self._action.result_callback:
            return self._action.result_callback(goal_handle)
        return GoalResponse.REJECT