# varioboticOS-base
Base module for the implementation of specific varioboticOS modules
