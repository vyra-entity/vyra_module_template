"""VYRA Interface Tools - Generate ROS2 interfaces from JSON metadata."""
