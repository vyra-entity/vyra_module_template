"""
Professional logging configuration for vyra_base library.

This module provides a centralized logging configuration that can be used
across all vyra_base modules. It supports:
- Console and file handlers with rotation
- Hierarchical logger configuration
- Environment-based log level control
- Structured log formatting
"""
import logging
import logging.config
import logging.handlers
import os
from pathlib import Path
from typing import Optional, Dict, Any


class VyraLoggingConfig:
    """
    Centralized logging configuration for vyra_base library.
    
    This class manages the logging configuration for the entire vyra_base library,
    providing consistent logging across all modules and components.
    """
    
    _initialized = False
    _default_level = logging.INFO
    _log_directory = Path("log/vyra")
    
    @classmethod
    def initialize(
        cls,
        log_level: Optional[str] = None,
        log_directory: Optional[Path] = None,
        log_config: Optional[Dict[str, Any]] = None,
        enable_console: bool = True,
        enable_file: bool = True,
    ) -> None:
        """
        Initialize the logging configuration.
        
        Args:
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
                      Can also be set via VYRA_LOG_LEVEL environment variable.
            log_directory: Directory where log files will be stored.
            log_config: Optional custom logging configuration dict.
            enable_console: Whether to enable console logging.
            enable_file: Whether to enable file logging.
        """
        if cls._initialized:
            logging.getLogger(__name__).debug("Logging already initialized, skipping")
            return
        
        # Determine log level from parameter or environment
        if log_level is None:
            log_level = os.getenv("VYRA_LOG_LEVEL", "INFO").upper()
        
        # Determine log directory
        if log_directory is not None:
            cls._log_directory = Path(log_directory)
        
        # Create log directory if it doesn't exist
        cls._log_directory.mkdir(parents=True, exist_ok=True)
        
        # Build configuration
        if log_config is None:
            log_config = cls._build_default_config(
                log_level=log_level,
                log_directory=cls._log_directory,
                enable_console=enable_console,
                enable_file=enable_file,
            )
        
        # Apply configuration
        logging.config.dictConfig(log_config)
        
        cls._initialized = True
        
        logger = logging.getLogger("vyra_base")
        logger.info(f"✅ Logging initialized (level={log_level}, dir={cls._log_directory})")
    
    @classmethod
    def _build_default_config(
        cls,
        log_level: str,
        log_directory: Path,
        enable_console: bool,
        enable_file: bool,
    ) -> Dict[str, Any]:
        """
        Build default logging configuration.
        
        Args:
            log_level: Logging level string.
            log_directory: Directory for log files.
            enable_console: Whether to enable console handler.
            enable_file: Whether to enable file handler.
            
        Returns:
            Logging configuration dictionary.
        """
        # Standard formatters
        formatters = {
            "standard": {
                "format": "%(asctime)s - %(name)s - %(levelname)-8s - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S"
            },
            "detailed": {
                "format": "%(asctime)s - %(name)s - %(levelname)-8s - [%(filename)s:%(lineno)d] - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S"
            },
            "simple": {
                "format": "%(levelname)-8s - %(name)s - %(message)s"
            }
        }
        
        # Configure handlers
        handlers = {}
        root_handlers = []
        
        if enable_console:
            handlers["console"] = {
                "class": "logging.StreamHandler",
                "level": log_level,
                "formatter": "standard",
                "stream": "ext://sys.stdout"
            }
            root_handlers.append("console")
        
        if enable_file:
            log_file = log_directory / "vyra_base.log"
            handlers["file"] = {
                "class": "logging.handlers.RotatingFileHandler",
                "level": log_level,
                "formatter": "detailed",
                "filename": str(log_file),
                "maxBytes": 10485760,  # 10MB
                "backupCount": 10,
                "encoding": "utf8"
            }
            root_handlers.append("file")
        
        # Loggers configuration
        loggers = {
            "vyra_base": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
            # Sub-loggers for specific modules
            "vyra_base.core": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
            "vyra_base.com": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
            "vyra_base.storage": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
            "vyra_base.state": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
            "vyra_base.security": {
                "level": log_level,
                "handlers": root_handlers,
                "propagate": False
            },
        }
        
        config = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": formatters,
            "handlers": handlers,
            "loggers": loggers,
            "root": {
                "level": "WARNING",
                "handlers": root_handlers if root_handlers else []
            }
        }
        
        return config
    
    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        """
        Get a logger instance.
        
        Ensures logging is initialized before returning the logger.
        
        Args:
            name: Logger name (typically __name__ of the module).
            
        Returns:
            Logger instance.
        """
        if not cls._initialized:
            cls.initialize()
        
        return logging.getLogger(name)
    
    @classmethod
    def set_level(cls, level: str, logger_name: Optional[str] = None) -> None:
        """
        Dynamically change logging level.
        
        Args:
            level: New logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
            logger_name: Specific logger to update, or None for root vyra_base logger.
        """
        if logger_name is None:
            logger_name = "vyra_base"
        
        logger = logging.getLogger(logger_name)
        numeric_level = getattr(logging, level.upper(), logging.INFO)
        logger.setLevel(numeric_level)
        
        # Also update handlers
        for handler in logger.handlers:
            handler.setLevel(numeric_level)
        
        logger.info(f"Log level changed to {level} for {logger_name}")
    
    @classmethod
    def add_handler_to_logger(cls, logger_name: str, handler: logging.Handler) -> None:
        """
        Add a custom handler to a specific logger.
        
        This is useful for adding additional logging outputs (e.g., to external systems).
        
        Args:
            logger_name: Name of the logger to add handler to.
            handler: Handler instance to add.
        """
        logger = logging.getLogger(logger_name)
        
        # Avoid duplicate handlers
        if handler not in logger.handlers:
            logger.addHandler(handler)
            logger.debug(f"Added custom handler to {logger_name}")
    
    @classmethod
    def reset(cls) -> None:
        """
        Reset the logging configuration.
        
        This is mainly useful for testing.
        """
        cls._initialized = False
        logging.root.handlers.clear()


def get_logger(name: str) -> logging.Logger:
    """
    Convenience function to get a logger.
    
    Args:
        name: Logger name (typically __name__).
        
    Returns:
        Logger instance.
    """
    return VyraLoggingConfig.get_logger(name)
